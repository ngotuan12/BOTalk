package com.brainyxlib.image;

public class ImageVo {

	public String img_url;
	public boolean img_flag;

	public String getImg_url() {
		return img_url;
	}

	public void setImg_url(String img_url) {
		this.img_url = img_url;
	}

	public boolean isImg_flag() {
		return img_flag;
	}

	public void setImg_flag(boolean img_flag) {
		this.img_flag = img_flag;
	}

}
