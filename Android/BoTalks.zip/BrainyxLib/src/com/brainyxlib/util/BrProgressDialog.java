package com.brainyxlib.util;

//import android.content.Context;
//import android.support.v7.internal.widget.ProgressBarICS;
//import android.util.AttributeSet;
//
//public class BrProgressDialog extends ProgressBarICS{
//
//	public BrProgressDialog(Context context, AttributeSet attrs, int defStyle,
//			int styleRes) {
//		super(context, attrs, defStyle, styleRes);
//		// TODO Auto-generated constructor stub
//	}
//}
