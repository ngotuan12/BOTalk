package com.brainyxlib;

public class BaseGlobal {

	public static final String PushKey = "pushkey";
	public static final String User_id = "userid";
	public static final String User_pw = "userpw";
	public static final String User_Seq = "userseq";
	public static final String User_Phone = "userphone";
	public static final String User_name = "username";
	public static final String AutoLogin = "autologin";
	
	
}
