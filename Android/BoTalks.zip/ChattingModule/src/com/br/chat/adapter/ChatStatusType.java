package com.br.chat.adapter;

public class ChatStatusType {

	public static final int SendSuc = 1;
	public static final int SendFail = 2;
	public static final int SendIng = 3;
	public static final int Send = 4;
}
