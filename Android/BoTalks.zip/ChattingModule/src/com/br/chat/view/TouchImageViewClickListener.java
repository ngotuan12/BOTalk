package com.br.chat.view;

public interface TouchImageViewClickListener {
	public void clicked();
}
