package com.br.chat.vo;

public class Constans {
	public final static String MSG_KEY = "msgkey";
	//public final static String RECEVE_SEQ = "recevseq";
	public final static String MEMBER_SEQ = "memberseq";
	public final static String SEND_SEQ = "sendseq";
	public final static String MESSAGE = "msg";
	public final static String SEND_NAME = "sendname";
	public final static String SEND_TYPE = "sendtype";
	public final static String ROOM_SEQ = "roomseq";
	public final static String ROOM_TYPE = "roomtype";
	public final static String REV_NAME = "revname";
	public final static String MEM_NAME = "membername";
	public final static String REG_DATE = "msgregdate";
}
