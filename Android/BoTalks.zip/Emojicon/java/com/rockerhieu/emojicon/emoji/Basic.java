package com.rockerhieu.emojicon.emoji;

import com.rockerhieu.emojicon.R;


public class Basic {
	public static final Emojicon[] DATA = new Emojicon[]{
		
		Emojicon.fromResource(R.drawable.emoji_1, 0),
		Emojicon.fromResource(R.drawable.emoji_2, 1),
		Emojicon.fromResource(R.drawable.emoji_3, 2)
		
	};
}
